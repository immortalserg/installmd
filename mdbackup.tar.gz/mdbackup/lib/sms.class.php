<?php

/*
 * @version 0.1 (auto-set)
 */

 /**
  * Summary of sms
  * @access public
  * @param mixed $phone   Phone number
  * @param mixed $message Message
  * @return void
  */
function sms($phone, $message)
{
}
