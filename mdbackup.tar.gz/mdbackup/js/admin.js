$(function() {
	$('input[name=filter_modules]').keyup(function() {
		filterModules();
	});
});