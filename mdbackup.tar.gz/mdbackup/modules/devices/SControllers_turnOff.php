<?php

$this->setProperty('status', 0);