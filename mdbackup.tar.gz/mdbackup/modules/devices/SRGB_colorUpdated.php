<?php

$color=$this->getProperty('color');
if ($color!='000000') {
    $this->setProperty('colorSaved',$color);
}
