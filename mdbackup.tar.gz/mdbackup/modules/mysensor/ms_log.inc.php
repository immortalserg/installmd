<?php

global $session;
global $filter;

$out['FILTER']=$filter;
$rec = array();

outHash($rec, $out);

?>